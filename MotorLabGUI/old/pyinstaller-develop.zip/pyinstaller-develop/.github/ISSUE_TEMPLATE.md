If you have problems to get your application running, please first

* follow the instructions in our "If Things Go Wrong" Guide
  (https://github.com/pyinstaller/pyinstaller/wiki/If-Things-Go-Wrong) and

* make sure everything is packaged correctly
  https://github.com/pyinstaller/pyinstaller/wiki/How-to-Report-Bugs#make-sure-everything-is-packaged-correctly

If you problem persists, please provide all information as stated in our "How to Report Bugs" guide.
https://github.com/pyinstaller/pyinstaller/wiki/How-to-Report-Bugs.

**Otherwise we will not be able to help you.**
